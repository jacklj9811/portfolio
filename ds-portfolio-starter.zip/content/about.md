// shim for Next import — re-export TS
export { default } from './about.md.ts';
